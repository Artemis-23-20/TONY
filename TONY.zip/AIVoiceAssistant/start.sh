#!/bin/bash

# Controllo se npm è installato
if ! command -v npm &> /dev/null; then
    echo "❌ npm non è installato. Per favore installa Node.js e npm."
    exit 1
fi

# Installa le dipendenze se necessario
if [ ! -d "node_modules" ]; then
    echo "📦 Installazione delle dipendenze..."
    npm install
fi

# Avvia l'applicazione
echo "🚀 Avvio TONY - Assistente Vocale..."
echo "⌛ Attendere il caricamento..."
npm run dev

# In caso di errore
if [ $? -ne 0 ]; then
    echo "❌ Errore durante l'avvio dell'applicazione."
    exit 1
fi
