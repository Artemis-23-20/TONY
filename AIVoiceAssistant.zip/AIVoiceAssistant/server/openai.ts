import { GoogleGenerativeAI } from "@google/generative-ai";
import type { AIResponse } from "@shared/types";

if (!process.env.GOOGLE_GEMINI_API_KEY) {
  throw new Error("GOOGLE_GEMINI_API_KEY is required");
}

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-pro" });

export async function processAICommand(command: string): Promise<AIResponse> {
  try {
    console.log('Processing command:', command);

    const prompt = `Agisci come un assistente vocale italiano chiamato TONY. In base a questo comando: "${command}", fornisci una risposta in questo formato JSON: {"text": "la tua risposta qui", "action": "azione opzionale"}. Mantieni le risposte concise e naturali, sempre in italiano.`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();

    console.log('Raw AI response:', text);

    try {
      // Prova a parsare come JSON
      return JSON.parse(text);
    } catch (error) {
      console.log('Failed to parse JSON, using raw text');
      // Se non è un JSON valido, incapsula il testo nel formato atteso
      return {
        text: text.trim()
      };
    }
  } catch (error) {
    console.error('Gemini API error:', error);
    if (error.message?.includes('API_KEY_INVALID')) {
      throw new Error('Invalid API key. Please check your GOOGLE_GEMINI_API_KEY configuration.');
    }
    throw new Error('Failed to process command with AI');
  }
}