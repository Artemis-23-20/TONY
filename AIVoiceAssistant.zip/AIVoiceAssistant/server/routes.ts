import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { processAICommand } from "./openai";
import { insertConversationSchema } from "@shared/schema";

export function registerRoutes(app: Express) {
  app.post('/api/process-command', async (req, res) => {
    try {
      const { command } = req.body;
      
      if (!command || typeof command !== 'string') {
        return res.status(400).json({ message: 'Invalid command' });
      }

      const response = await processAICommand(command);
      
      // Store conversation
      await storage.createConversation({
        query: command,
        response: response.text
      });

      res.json(response);
    } catch (error) {
      console.error('Error processing command:', error);
      res.status(500).json({ message: 'Failed to process command' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
