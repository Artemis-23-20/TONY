import { Card, CardContent } from "./ui/card";

export function ResponseDisplay({ text }: { text: string }) {
  if (!text) return null;

  return (
    <Card className="w-full">
      <CardContent className="pt-4">
        <p className="text-lg">{text}</p>
      </CardContent>
    </Card>
  );
}
