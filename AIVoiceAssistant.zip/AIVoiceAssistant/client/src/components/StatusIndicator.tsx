import { cn } from "@/lib/utils";
import type { VoiceStatus } from "@shared/types";

const statusConfig = {
  idle: { color: "bg-muted", text: "Ready" },
  listening: { color: "bg-green-500", text: "Listening..." },
  processing: { color: "bg-blue-500", text: "Processing..." },
  speaking: { color: "bg-purple-500", text: "Speaking..." },
  error: { color: "bg-red-500", text: "Error" },
};

export function StatusIndicator({ status }: { status: VoiceStatus }) {
  const config = statusConfig[status];

  return (
    <div className="flex items-center gap-2">
      <div className="flex gap-2 items-center rounded-full bg-muted px-4 py-2">
        <div
          className={cn(
            "h-3 w-3 rounded-full animate-pulse",
            config.color
          )}
        />
        <span className="text-sm font-medium">{config.text}</span>
      </div>
    </div>
  );
}
