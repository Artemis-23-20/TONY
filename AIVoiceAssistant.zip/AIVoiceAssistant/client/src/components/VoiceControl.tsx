import { useState, useEffect } from "react";
import { Mic, MicOff } from "lucide-react";
import { Button } from "./ui/button";
import { StatusIndicator } from "./StatusIndicator";
import { ResponseDisplay } from "./ResponseDisplay";
import { SpeechHandler } from "@/lib/speech";
import { processCommand } from "@/lib/openai";
import { useToast } from "@/hooks/use-toast";
import type { VoiceStatus } from "@shared/types";

export function VoiceControl() {
  const [status, setStatus] = useState<VoiceStatus>('idle');
  const [response, setResponse] = useState<string>('');
  const { toast } = useToast();
  const [speechHandler, setSpeechHandler] = useState<SpeechHandler | null>(null);

  useEffect(() => {
    const handler = new SpeechHandler(
      (newStatus) => setStatus(newStatus),
      async (command) => {
        try {
          setStatus('processing');
          const result = await processCommand(command);
          setResponse(result.text);
          handler.speak(result.text);
        } catch (error) {
          toast({
            title: "Error",
            description: "Failed to process command",
            variant: "destructive"
          });
          setStatus('error');
        }
      }
    );
    setSpeechHandler(handler);

    return () => {
      handler.stopListening();
    };
  }, [toast]);

  const toggleListening = () => {
    if (status === 'listening') {
      speechHandler?.stopListening();
    } else {
      speechHandler?.startListening();
    }
  };

  return (
    <div className="w-full flex flex-col items-center gap-6">
      <StatusIndicator status={status} />
      
      <Button
        size="lg"
        variant={status === 'listening' ? "destructive" : "default"}
        onClick={toggleListening}
        className="h-16 w-16 rounded-full"
      >
        {status === 'listening' ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
      </Button>

      <ResponseDisplay text={response} />
    </div>
  );
}
