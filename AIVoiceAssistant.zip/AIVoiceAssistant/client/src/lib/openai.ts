import { apiRequest } from "./queryClient";
import type { AIResponse } from "@shared/types";

export async function processCommand(command: string): Promise<AIResponse> {
  try {
    const response = await apiRequest('POST', '/api/process-command', { command });
    return await response.json();
  } catch (error) {
    console.error('Error processing command:', error);
    throw error;
  }
}
