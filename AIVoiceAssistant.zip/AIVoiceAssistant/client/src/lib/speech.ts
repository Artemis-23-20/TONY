import { VoiceStatus } from "@shared/types";

// Add type definitions for the Web Speech API
declare global {
  interface Window {
    SpeechRecognition: typeof SpeechRecognition;
    webkitSpeechRecognition: typeof SpeechRecognition;
  }
}

export class SpeechHandler {
  private recognition: SpeechRecognition;
  private synthesis: SpeechSynthesisUtterance;
  private onStatusChange: (status: VoiceStatus) => void;
  private onResult: (text: string) => void;
  private isListening = false;

  constructor(
    onStatusChange: (status: VoiceStatus) => void,
    onResult: (text: string) => void
  ) {
    this.onStatusChange = onStatusChange;
    this.onResult = onResult;

    // Initialize speech recognition
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    this.recognition = new SpeechRecognition();
    this.recognition.continuous = true;
    this.recognition.interimResults = false;
    this.recognition.lang = 'it-IT'; // Imposta italiano come lingua

    // Initialize speech synthesis
    this.synthesis = new SpeechSynthesisUtterance();
    this.synthesis.lang = 'it-IT'; // Imposta italiano come lingua
    this.synthesis.rate = 1.0; // Velocità normale
    this.synthesis.pitch = 1.0; // Tono normale
    this.synthesis.volume = 1.0; // Volume massimo

    // Try to select an Italian voice if available
    window.speechSynthesis.onvoiceschanged = () => {
      const voices = window.speechSynthesis.getVoices();
      const italianVoice = voices.find(voice => voice.lang.includes('it-IT'));
      if (italianVoice) {
        this.synthesis.voice = italianVoice;
      }
    };

    this.setupListeners();
  }

  private setupListeners() {
    this.recognition.onstart = () => {
      this.isListening = true;
      this.onStatusChange('listening');
    };

    this.recognition.onend = () => {
      this.isListening = false;
      if (this.recognition.error) {
        this.onStatusChange('error');
      } else {
        this.onStatusChange('idle');
      }
    };

    this.recognition.onresult = (event: SpeechRecognitionEvent) => {
      const text = event.results[event.results.length - 1][0].transcript.toLowerCase();
      if (text.includes('tony')) {
        this.onResult(text.replace('tony', '').trim());
      }
    };

    this.recognition.onerror = () => {
      this.onStatusChange('error');
    };

    this.synthesis.onstart = () => {
      this.onStatusChange('speaking');
    };

    this.synthesis.onend = () => {
      this.onStatusChange('idle');
    };
  }

  public startListening() {
    try {
      if (!this.isListening) {
        this.recognition.start();
      }
    } catch (error) {
      console.error('Speech recognition error:', error);
      this.onStatusChange('error');
    }
  }

  public stopListening() {
    if (this.isListening) {
      this.recognition.stop();
    }
  }

  public speak(text: string) {
    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    this.synthesis.text = text;
    window.speechSynthesis.speak(this.synthesis);
  }
}