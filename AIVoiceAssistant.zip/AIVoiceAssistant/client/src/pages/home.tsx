import { VoiceControl } from "@/components/VoiceControl";
import { Card, CardContent } from "@/components/ui/card";

export default function Home() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-b from-background to-muted p-4">
      <Card className="w-full max-w-2xl">
        <CardContent className="pt-6 flex flex-col items-center gap-6">
          <h1 className="text-4xl font-bold text-center bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
            TONY - Assistente Vocale
          </h1>
          <p className="text-muted-foreground text-center">
            Di "TONY" per attivare i comandi vocali
          </p>
          <VoiceControl />
        </CardContent>
      </Card>
    </div>
  );
}