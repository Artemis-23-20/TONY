export interface AIResponse {
  text: string;
  action?: string;
}

export type VoiceStatus = 'idle' | 'listening' | 'processing' | 'speaking' | 'error';
